package android.example.popularmoviess1.model;

public class MoviesModel {
//     "popularity": 264.191,
//             "vote_count": 2456,
//             "video": false,
//             "poster_path": "/y95lQLnuNKdPAzw9F9Ab8kJ80c3.jpg",
//             "id": 38700,
//             "adult": false,
//             "backdrop_path": "/upUy2QhMZEmtypPW3PdieKLAHxh.jpg",
//             "original_language": "en",
//             "original_title": "Bad Boys for Life",
//             "genre_ids": [
//             28,
//             80,
//             53
//             ],
//             "title": "Bad Boys for Life",
//             "vote_average": 7.1,
//             "overview": "Marcus and Mike are forced to confront new threats, career changes, and midlife crises as they join the newly created elite team AMMO of the Miami police department to take down the ruthless Armando Armas, the vicious leader of a Miami drug cartel.",
//             "release_date": "2020-01-15"
//}

    private boolean adult;
    private String posterUrl;
    private String backdropUrl;
    private int id;
    private String originalLanguage;
    private String title;
    private String voteAverage;
    private String overview;
    private String releaseDate;
}
